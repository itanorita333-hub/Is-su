// 🧹 Fix for ENOSPC / temp overflow in hosted panels
const fs = require('fs');
const path = require('path');

// Redirect temp storage away from system /tmp
const customTemp = path.join(process.cwd(), 'temp');
if (!fs.existsSync(customTemp)) fs.mkdirSync(customTemp, { recursive: true });
process.env.TMPDIR = customTemp;
process.env.TEMP = customTemp;
process.env.TMP = customTemp;

// Auto-cleaner every 3 hours
setInterval(() => {
    fs.readdir(customTemp, (err, files) => {
        if (err) return;
        for (const file of files) {
            const filePath = path.join(customTemp, file);
            fs.stat(filePath, (err, stats) => {
                if (!err && Date.now() - stats.mtimeMs > 3 * 60 * 60 * 1000) {
                    fs.unlink(filePath, () => { });
                }
            });
        }
    });
    console.log('🧹 Temp folder auto-cleaned');
}, 3 * 60 * 60 * 1000);

const settings = require('./settings');
require('./config.js');
const { isBanned } = require('./lib/isBanned');
const store = require('./lib/lightweight_store');
const yts = require('yt-search');
const { fetchBuffer } = require('./lib/myfunc');
const fetch = require('node-fetch');
const ytdl = require('ytdl-core');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const { isSudo } = require('./lib/index');
const isOwnerOrSudo = require('./lib/isOwner');
const { autotypingCommand, isAutotypingEnabled, handleAutotypingForMessage, handleAutotypingForCommand, showTypingAfterCommand } = require('./commands/autotyping');
const { autoreadCommand, isAutoreadEnabled, handleAutoread } = require('./commands/autoread');

// Command imports
const tagAllCommand = require('./commands/tagall');
const helpCommand = require('./commands/help');
const banCommand = require('./commands/ban');
const { promoteCommand } = require('./commands/promote');
const { demoteCommand } = require('./commands/demote');
const muteCommand = require('./commands/mute');
const unmuteCommand = require('./commands/unmute');
const stickerCommand = require('./commands/sticker');
const isAdmin = require('./lib/isAdmin');
const warnCommand = require('./commands/warn');
const warningsCommand = require('./commands/warnings');
const ttsCommand = require('./commands/tts');
const { handleTicTacToeMove } = require('./commands/tictactoe');
const { incrementMessageCount, topMembers } = require('./commands/topmembers');
const ownerCommand = require('./commands/owner');
const deleteCommand = require('./commands/delete');
const { handleAntilinkCommand, handleLinkDetection } = require('./commands/antilink');
const { handleAntitagCommand, handleTagDetection } = require('./commands/antitag');
const { Antilink } = require('./lib/antilink');
const { handleMentionDetection, mentionToggleCommand, setMentionCommand } = require('./commands/mention');
const memeCommand = require('./commands/meme');
const tagCommand = require('./commands/tag');
const tagNotAdminCommand = require('./commands/tagnotadmin');
const hideTagCommand = require('./commands/hidetag');
const jokeCommand = require('./commands/joke');
const quoteCommand = require('./commands/quote');
const factCommand = require('./commands/fact');
const weatherCommand = require('./commands/weather');
const newsCommand = require('./commands/news');
const kickCommand = require('./commands/kick');
const simageCommand = require('./commands/simage');
const attpCommand = require('./commands/attp');
const { eightBallCommand } = require('./commands/eightball');
const { lyricsCommand } = require('./commands/lyrics');
const { clearCommand } = require('./commands/clear');
const pingCommand = require('./commands/ping');
const aliveCommand = require('./commands/alive');
const blurCommand = require('./commands/img-blur');
const { welcomeCommand, handleJoinEvent } = require('./commands/welcome');
const { goodbyeCommand, handleLeaveEvent } = require('./commands/goodbye');
const { handleAntiBadwordCommand, handleBadwordDetection } = require('./lib/antibadword');
const antibadwordCommand = require('./commands/antibadword');
const { handleChatbotCommand, handleChatbotResponse } = require('./commands/chatbot');
const takeCommand = require('./commands/take');
const groupInfoCommand = require('./commands/groupinfo');
const resetlinkCommand = require('./commands/resetlink');
const staffCommand = require('./commands/staff');
const unbanCommand = require('./commands/unban');
const emojimixCommand = require('./commands/emojimix');
const { handlePromotionEvent } = require('./commands/promote');
const { handleDemotionEvent } = require('./commands/demote');
const viewOnceCommand = require('./commands/viewonce');
const clearSessionCommand = require('./commands/clearsession');
const { autoStatusCommand, handleStatusUpdate } = require('./commands/autostatus');
const stickerTelegramCommand = require('./commands/stickertelegram');
const { handleAntideleteCommand, handleMessageRevocation, storeMessage } = require('./commands/antidelete');
const clearTmpCommand = require('./commands/cleartmp');
const setProfilePicture = require('./commands/setpp');
const { setGroupDescription, setGroupName, setGroupPhoto } = require('./commands/groupmanage');
const instagramCommand = require('./commands/instagram');
const facebookCommand = require('./commands/facebook');
const spotifyCommand = require('./commands/spotify');
const ytmp3Command = require('./commands/ytmp3');
const tiktokCommand = require('./commands/tiktok');
const toMp3Command = require('./commands/tomp3');
const urlCommand = require('./commands/url');
const { handleTranslateCommand } = require('./commands/translate');
const { handleSsCommand } = require('./commands/ss');
const { addCommandReaction, handleAreactCommand } = require('./lib/reactions');
const videoCommand = require('./commands/video');
const twilioCommand = require('./commands/twilio');
const sudoCommand = require('./commands/sudo');
const { miscCommand } = require('./commands/misc');
const { animeCommand } = require('./commands/anime');
const stickercropCommand = require('./commands/stickercrop');
const updateCommand = require('./commands/update');
const removebgCommand = require('./commands/removebg');
const { reminiCommand } = require('./commands/remini');
const { igsCommand } = require('./commands/igs');
const { anticallCommand, readState: readAnticallState } = require('./commands/anticall');
const { pmblockerCommand, readState: readPmBlockerState } = require('./commands/pmblocker');
const pairCommand = require('./commands/pair');
const settingsCommand = require('./commands/settings');
const setTimezoneCommand = require('./commands/settimezone');
const scheduleCommand = require('./commands/schedule');
const singleSelectCommand = require('./commands/singleselect');
const { sendInteractiveButtons, extractInteractiveResponseId } = require('./lib/interactiveButtons');

// Global settings
global.packname = settings.packname;
global.author = settings.author;
global.channelLink = "https://whatsapp.com/channel/0029Va90zAnIHphOuO8Msp3A";
global.ytch = "Mr Unique Hacker";

// Add this near the top of main.js with other global configurations
const channelInfo = {
    contextInfo: {
        forwardingScore: 0,
        isForwarded: false
    }
};

const MESSAGE_COUNT_PATH = './data/messageCount.json'
const DEFAULT_MESSAGE_COUNT_STATE = {
    isPublic: true,
    messageCount: {}
}

function ensureMessageCountDataFile() {
    try {
        if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true })
        if (!fs.existsSync(MESSAGE_COUNT_PATH)) {
            fs.writeFileSync(MESSAGE_COUNT_PATH, JSON.stringify(DEFAULT_MESSAGE_COUNT_STATE, null, 2))
        }
    } catch (_) {}
}

function readMessageCountData() {
    ensureMessageCountDataFile()
    try {
        const parsed = JSON.parse(fs.readFileSync(MESSAGE_COUNT_PATH, 'utf8'))
        if (parsed && typeof parsed === 'object') return parsed
    } catch (_) {}

    const fallback = { ...DEFAULT_MESSAGE_COUNT_STATE }
    writeMessageCountData(fallback)
    return fallback
}

function writeMessageCountData(data) {
    ensureMessageCountDataFile()
    try {
        const payload = (data && typeof data === 'object') ? data : { ...DEFAULT_MESSAGE_COUNT_STATE }
        fs.writeFileSync(MESSAGE_COUNT_PATH, JSON.stringify(payload, null, 2))
    } catch (_) {}
}

function parseCustomButtonParams(button) {
    const raw = button?.buttonParamsJson
    if (!raw) return null

    if (typeof raw === 'string') {
        try {
            return JSON.parse(raw)
        } catch (_) {
            return null
        }
    }

    if (typeof raw === 'object') return raw
    return null
}

function getNativeButtonDedupKey(button) {
    if (!button || typeof button !== 'object') return ''

    const name = String(button.name || '').trim()
    const rawParams = button.buttonParamsJson
    let params = {}

    if (typeof rawParams === 'string') {
        try {
            params = JSON.parse(rawParams)
        } catch (_) {
            params = {}
        }
    } else if (rawParams && typeof rawParams === 'object') {
        params = rawParams
    }

    if (name === 'quick_reply') {
        return `quick_reply:${String(params.id || params.buttonId || '').trim()}:${String(params.display_text || params.displayText || '').trim()}`
    }

    if (name === 'cta_url') {
        return `cta_url:${String(params.url || params.link || params.merchant_url || '').trim()}:${String(params.display_text || params.displayText || '').trim()}`
    }

    if (name === 'cta_call') {
        return `cta_call:${String(params.phone_number || params.phoneNumber || '').trim()}:${String(params.display_text || params.displayText || '').trim()}`
    }

    return `${name}:${typeof rawParams === 'string' ? rawParams.trim() : JSON.stringify(rawParams || {})}`
}

function normalizeCustomCommandButtons(buttons) {
    if (!Array.isArray(buttons) || !buttons.length) return { buttons: null, templateButtons: null, nativeButtons: null }

    const templateButtons = []
    const legacyButtons = []
    const passthroughNativeButtons = []

    for (const button of buttons) {
        if (!button || typeof button !== 'object') continue

        // Keep full native flow button payloads (wabase-button style)
        if (button.name && button.buttonParamsJson) {
            passthroughNativeButtons.push({
                name: String(button.name),
                buttonParamsJson: typeof button.buttonParamsJson === 'string'
                    ? button.buttonParamsJson
                    : JSON.stringify(button.buttonParamsJson)
            })

            // Build template/legacy fallback for common button types
            const params = parseCustomButtonParams(button) || {}
            if (button.name === 'quick_reply') {
                const displayText = params.display_text || params.displayText || 'Button'
                const buttonId = params.id || params.buttonId || displayText
                templateButtons.push(button.index ? { index: button.index, quickReplyButton: { displayText, id: buttonId } } : { quickReplyButton: { displayText, id: buttonId } })
                legacyButtons.push({ buttonId, buttonText: { displayText }, type: 1 })
            } else if (button.name === 'cta_url') {
                const displayText = params.display_text || params.displayText || 'Open Link'
                const url = params.url || params.link || params.merchant_url
                if (url) templateButtons.push(button.index ? { index: button.index, urlButton: { displayText, url } } : { urlButton: { displayText, url } })
            } else if (button.name === 'cta_call') {
                const displayText = params.display_text || params.displayText || 'Call'
                const phoneNumber = params.phone_number || params.phoneNumber || params.id
                if (phoneNumber) templateButtons.push(button.index ? { index: button.index, callButton: { displayText, phoneNumber } } : { callButton: { displayText, phoneNumber } })
            } else if (button.name === 'cta_copy') {
                const displayText = params.display_text || params.displayText || 'Copy'
                const copyCode = params.copy_code || params.copyCode || params.id || displayText
                templateButtons.push(button.index ? { index: button.index, quickReplyButton: { displayText, id: copyCode } } : { quickReplyButton: { displayText, id: copyCode } })
                legacyButtons.push({ buttonId: String(copyCode), buttonText: { displayText }, type: 1 })
            } else if (button.name === 'single_select') {
                const displayText = params.title || params.display_text || params.displayText || 'Choose Option'
                const firstRowId = Array.isArray(params.sections)
                    ? params.sections.flatMap(section => Array.isArray(section?.rows) ? section.rows : []).find(row => row?.id)?.id
                    : ''
                if (firstRowId) {
                    templateButtons.push(button.index ? { index: button.index, quickReplyButton: { displayText, id: firstRowId } } : { quickReplyButton: { displayText, id: firstRowId } })
                    legacyButtons.push({ buttonId: String(firstRowId), buttonText: { displayText }, type: 1 })
                }
            }
            continue
        }

        if (button.quickReplyButton) {
            templateButtons.push(button.index ? { index: button.index, quickReplyButton: button.quickReplyButton } : { quickReplyButton: button.quickReplyButton })
            continue
        }
        if (button.urlButton) {
            templateButtons.push(button.index ? { index: button.index, urlButton: button.urlButton } : { urlButton: button.urlButton })
            continue
        }
        if (button.callButton) {
            templateButtons.push(button.index ? { index: button.index, callButton: button.callButton } : { callButton: button.callButton })
            continue
        }

        if (button.name === 'whatsapp') {
            const params = parseCustomButtonParams(button) || {}
            const displayText = params.display_text || params.displayText || 'Open WhatsApp'
            const phoneNumber = String(params.phone_number || params.phoneNumber || '').replace(/\D/g, '')
            const url = phoneNumber ? `https://wa.me/${phoneNumber}` : params.url
            if (url) templateButtons.push(button.index ? { index: button.index, urlButton: { displayText, url } } : { urlButton: { displayText, url } })
            continue
        }

        if (button.name === 'url') {
            const params = parseCustomButtonParams(button) || {}
            const displayText = params.display_text || params.displayText || 'Open Link'
            const url = params.url || params.link
            if (url) templateButtons.push(button.index ? { index: button.index, urlButton: { displayText, url } } : { urlButton: { displayText, url } })
            continue
        }

        if (button.name === 'call') {
            const params = parseCustomButtonParams(button) || {}
            const displayText = params.display_text || params.displayText || 'Call'
            const phoneNumber = params.phone_number || params.phoneNumber
            if (phoneNumber) templateButtons.push(button.index ? { index: button.index, callButton: { displayText, phoneNumber } } : { callButton: { displayText, phoneNumber } })
            continue
        }

        if (button.name === 'quick_reply' || button.buttonId || button.buttonText || button.buttonParamsJson) {
            const params = parseCustomButtonParams(button) || {}
            const displayText = params.display_text || params.displayText || button.buttonText?.displayText || params.title || button.title || 'Button'
            const buttonId = params.id || params.buttonId || button.buttonId || displayText
            templateButtons.push(button.index ? { index: button.index, quickReplyButton: { displayText, id: buttonId } } : { quickReplyButton: { displayText, id: buttonId } })
            legacyButtons.push({ buttonId, buttonText: { displayText }, type: 1 })
            continue
        }
    }

    const nativeButtons = []
    const seenNativeButtonKeys = new Set()
    const addNativeButton = (button) => {
        const key = getNativeButtonDedupKey(button)
        if (!key || seenNativeButtonKeys.has(key)) return
        seenNativeButtonKeys.add(key)
        nativeButtons.push(button)
    }

    for (const button of passthroughNativeButtons) addNativeButton(button)

    for (const button of templateButtons) {
        if (button.quickReplyButton?.id) {
            addNativeButton({
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: button.quickReplyButton.displayText || 'Button',
                    id: button.quickReplyButton.id
                })
            })
            continue
        }
        if (button.urlButton?.url) {
            addNativeButton({
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: button.urlButton.displayText || 'Open Link',
                    url: button.urlButton.url,
                    merchant_url: button.urlButton.url
                })
            })
            continue
        }
        if (button.callButton?.phoneNumber) {
            addNativeButton({
                name: 'cta_call',
                buttonParamsJson: JSON.stringify({
                    display_text: button.callButton.displayText || 'Call',
                    phone_number: String(button.callButton.phoneNumber)
                })
            })
        }
    }

    return {
        templateButtons: templateButtons.length ? templateButtons : null,
        buttons: legacyButtons.length ? legacyButtons : null,
        nativeButtons: nativeButtons.length ? nativeButtons : null
    }
}

async function handleMessages(sock, messageUpdate, printLog) {
    let chatId;
    try {
        const { messages, type } = messageUpdate;
        if (type !== 'notify') return;

        const message = messages[0];
        if (!message?.message) return;

        // Handle autoread functionality
        await handleAutoread(sock, message);

        // Store message for antidelete feature
        if (message.message) {
            storeMessage(sock, message);
        }

        // Handle message revocation
        if (message.message?.protocolMessage?.type === 0) {
            await handleMessageRevocation(sock, message);
            return;
        }

        chatId = message.key.remoteJid;
        const senderId = message.key.participant || message.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');

        // Cache group name in store if not yet known
        if (isGroup) {
            if (!store.chats || typeof store.chats !== 'object') {
                store.chats = {};
            }
            const cached = store.chats[chatId];
            if (!cached || !cached.subject) {
                try {
                    const meta = await sock.groupMetadata(chatId);
                    if (meta?.subject) {
                        store.chats[chatId] = { id: chatId, subject: meta.subject };
                    }
                } catch (_) {}
            }
        }

        const senderIsSudo = await isSudo(senderId);
        const senderIsOwnerOrSudo = await isOwnerOrSudo(senderId, sock, chatId);

        // Handle button responses
        const interactiveButtonId = extractInteractiveResponseId(message);
        if (interactiveButtonId) {
            const buttonId = interactiveButtonId;
            const chatId = message.key.remoteJid;

            if (buttonId === 'channel') {
                await sock.sendMessage(chatId, {
                    text: '📢 *Join our Channel:*\nhttps://whatsapp.com/channel/0029Va90zAnIHphOuO8Msp3A'
                });
                return;
            } else if (buttonId === 'owner') {
                const ownerCommand = require('./commands/owner');
                await ownerCommand(sock, chatId);
                return;
            } else if (buttonId === 'support') {
                await sock.sendMessage(chatId, {
                    text: `🔗 *Support*\n\nhttps://chat.whatsapp.com/GA4WrOFythU6g3BFVubYM7?mode=wwt`
                });
                return;
            }
        }

        const userMessage = (
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            interactiveButtonId?.trim() ||
            ''
        ).toLowerCase().replace(/\.\s+/g, '.').trim();

        // Preserve raw message for commands like .tag that need original casing
        const rawText = message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            '';

        // Only log command usage
        if (userMessage.startsWith('.')) {
            console.log(`📝 Command used in ${isGroup ? 'group' : 'private'}: ${userMessage}`);
        }
        // Read bot mode once; don't early-return so moderation can still run in private mode
        let isPublic = true;
        const modeData = readMessageCountData();
        if (typeof modeData.isPublic === 'boolean') isPublic = modeData.isPublic;
        const isOwnerOrSudoCheck = message.key.fromMe || senderIsOwnerOrSudo;
        // Check if user is banned (skip ban check for unban command)
        if (isBanned(senderId) && !userMessage.startsWith('.unban')) {
            // Only respond occasionally to avoid spam
            if (Math.random() < 0.1) {
                await sock.sendMessage(chatId, {
                    text: '❌ You are banned from using the bot. Contact an admin to get unbanned.',
                    ...channelInfo
                });
            }
            return;
        }

        // First check if it's a game move
        if (/^[1-9]$/.test(userMessage) || userMessage.toLowerCase() === 'surrender') {
            await handleTicTacToeMove(sock, chatId, senderId, userMessage);
            return;
        }

        /*  // Basic message response in private chat
          if (!isGroup && (userMessage === 'hi' || userMessage === 'hello' || userMessage === 'bot' || userMessage === 'hlo' || userMessage === 'hey' || userMessage === 'bro')) {
              await sock.sendMessage(chatId, {
                  text: 'Hi, How can I help you?\nYou can use .menu for more info and commands.',
                  ...channelInfo
              });
              return;
          } */

        if (!message.key.fromMe) incrementMessageCount(chatId, senderId);

        // Check for bad words and antilink FIRST, before ANY other processing
        // Always run moderation in groups, regardless of mode
        if (isGroup) {
            if (userMessage) {
                await handleBadwordDetection(sock, chatId, message, userMessage, senderId);
            }
            // Antilink checks message text internally, so run it even if userMessage is empty
            await Antilink(message, sock);
        }

        // PM blocker: block non-owner DMs when enabled (do not ban)
        if (!isGroup && !message.key.fromMe && !senderIsSudo) {
            try {
                const pmState = readPmBlockerState();
                if (pmState.enabled) {
                    // Inform user, delay, then block without banning globally
                    await sock.sendMessage(chatId, { text: pmState.message || 'Private messages are blocked. Please contact the owner in groups only.' });
                    await new Promise(r => setTimeout(r, 1500));
                    try { await sock.updateBlockStatus(chatId, 'block'); } catch (e) { }
                    return;
                }
            } catch (e) { }
        }

        // Then check for command prefix
        if (!userMessage.startsWith('.')) {
            // Show typing indicator if autotyping is enabled
            await handleAutotypingForMessage(sock, chatId, userMessage);

            if (isGroup) {
                // Always run moderation features (antitag) regardless of mode
                await handleTagDetection(sock, chatId, message, senderId);
                await handleMentionDetection(sock, chatId, message);

                // Only run chatbot in public mode or for owner/sudo
                if (isPublic || isOwnerOrSudoCheck) {
                    await handleChatbotResponse(sock, chatId, message, userMessage, senderId);
                }
            }
            return;
        }
        // In private mode, only owner/sudo can run commands
        if (!isPublic && !isOwnerOrSudoCheck) {
            return;
        }

        // Tag command trigger message so socket layer can avoid quoted replies.
        // This keeps command responses as normal messages instead of reply threads.
        try {
            Object.defineProperty(message, '__noReplyForCommand', {
                value: true,
                configurable: true,
                enumerable: false,
                writable: true,
            });
        } catch (_) {
            message.__noReplyForCommand = true;
        }

        // List of admin commands
        const adminCommands = ['.mute', '.unmute', '.ban', '.unban', '.promote', '.demote', '.kick', '.tagall', '.tagnotadmin', '.hidetag', '.antilink', '.antitag', '.setgdesc', '.setgname', '.setgpp'];
        const isAdminCommand = adminCommands.some(cmd => userMessage.startsWith(cmd));

        // List of owner commands
        const ownerCommands = ['.mode', '.autostatus', '.antidelete', '.cleartmp', '.setpp', '.clearsession', '.areact', '.autoreact', '.autotyping', '.autoread', '.pmblocker', '.settimezone', '.timezone'];
        const isOwnerCommand = ownerCommands.some(cmd => userMessage.startsWith(cmd));

        let isSenderAdmin = false;
        let isBotAdmin = false;

        // Check admin status only for admin commands in groups
        if (isGroup && isAdminCommand) {
            const adminStatus = await isAdmin(sock, chatId, senderId);
            isSenderAdmin = adminStatus.isSenderAdmin;
            isBotAdmin = adminStatus.isBotAdmin;

            if (!isBotAdmin) {
                await sock.sendMessage(chatId, { text: 'Please make the bot an admin to use admin commands.', ...channelInfo });
                return;
            }

            if (
                userMessage.startsWith('.mute') ||
                userMessage === '.unmute' ||
                userMessage.startsWith('.ban') ||
                userMessage.startsWith('.unban') ||
                userMessage.startsWith('.promote') ||
                userMessage.startsWith('.demote')
            ) {
                if (!isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, {
                        text: 'Sorry, only group admins can use this command.',
                        ...channelInfo
                    });
                    return;
                }
            }
        }

        // Check owner status for owner commands
        if (isOwnerCommand) {
            if (!message.key.fromMe && !senderIsOwnerOrSudo) {
                await sock.sendMessage(chatId, { text: '❌ This command is only available for the owner or sudo!' });
                return;
            }
        }

        // Command handlers - Execute commands immediately without waiting for typing indicator
        // We'll show typing indicator after command execution if needed
        let commandExecuted = false;

        switch (true) {
            case userMessage === '.simage': {
                const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                if (quotedMessage?.stickerMessage) {
                    await simageCommand(sock, quotedMessage, chatId);
                } else {
                    await sock.sendMessage(chatId, { text: 'Please reply to a sticker with the .simage command to convert it.', ...channelInfo });
                }
                commandExecuted = true;
                break;
            }
            case userMessage.startsWith('.kick'):
                const mentionedJidListKick = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await kickCommand(sock, chatId, senderId, mentionedJidListKick, message);
                break;
            case userMessage.startsWith('.mute'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const muteArg = parts[1];
                    const muteDuration = muteArg !== undefined ? parseInt(muteArg, 10) : undefined;
                    if (muteArg !== undefined && (isNaN(muteDuration) || muteDuration <= 0)) {
                        await sock.sendMessage(chatId, { text: 'Please provide a valid number of minutes or use .mute with no number to mute immediately.', ...channelInfo });
                    } else {
                        await muteCommand(sock, chatId, senderId, message, muteDuration);
                    }
                }
                break;
            case userMessage === '.unmute':
                if (isGroup && !isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, { text: 'Sorry, only group admins can use this command.', ...channelInfo });
                    break;
                }
                await unmuteCommand(sock, chatId, senderId);
                break;
            case userMessage.startsWith('.ban'):
                if (!isGroup) {
                    if (!message.key.fromMe && !senderIsSudo) {
                        await sock.sendMessage(chatId, { text: 'Only owner/sudo can use .ban in private chat.' });
                        break;
                    }
                }
                await banCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.unban'):
                if (!isGroup) {
                    if (!message.key.fromMe && !senderIsSudo) {
                        await sock.sendMessage(chatId, { text: 'Only owner/sudo can use .unban in private chat.' });
                        break;
                    }
                }
                await unbanCommand(sock, chatId, message);
                break;
            case userMessage === '.help' || userMessage === '.menu' || userMessage === '.bot' || userMessage === '.list':
                await helpCommand(sock, chatId, message, global.channelLink);
                commandExecuted = true;
                break;
            case userMessage === '.singleselect':
                await singleSelectCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage === '.sticker' || userMessage === '.s':
                await stickerCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.warnings'):
                const mentionedJidListWarnings = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await warningsCommand(sock, chatId, mentionedJidListWarnings);
                break;
            case userMessage.startsWith('.warn'):
                const mentionedJidListWarn = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await warnCommand(sock, chatId, senderId, mentionedJidListWarn, message);
                break;
            case userMessage.startsWith('.tts'):
                const text = userMessage.slice(4).trim();
                await ttsCommand(sock, chatId, text, message);
                break;
            case userMessage.startsWith('.delete') || userMessage.startsWith('.del'):
                await deleteCommand(sock, chatId, message, senderId);
                break;
            case userMessage.startsWith('.attp'):
                await attpCommand(sock, chatId, message);
                break;

            case userMessage === '.settings':
                await settingsCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.settimezone') || userMessage.startsWith('.timezone'):
                await setTimezoneCommand(sock, chatId, message, rawText);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.mode'):
                // Check if sender is the owner
                if (!message.key.fromMe && !senderIsOwnerOrSudo) {
                    await sock.sendMessage(chatId, { text: 'Only bot owner can use this command!', ...channelInfo });
                    return;
                }
                // Read current data first
                let data = readMessageCountData();

                const action = userMessage.split(' ')[1]?.toLowerCase();
                // If no argument provided, show current status
                if (!action) {
                    const currentMode = data.isPublic ? 'public' : 'private';
                    await sock.sendMessage(chatId, {
                        text: `Current bot mode: *${currentMode}*\n\nUsage: .mode public/private\n\nExample:\n.mode public - Allow everyone to use bot\n.mode private - Restrict to owner only`,
                        ...channelInfo
                    });
                    return;
                }

                if (action !== 'public' && action !== 'private') {
                    await sock.sendMessage(chatId, {
                        text: 'Usage: .mode public/private\n\nExample:\n.mode public - Allow everyone to use bot\n.mode private - Restrict to owner only',
                        ...channelInfo
                    });
                    return;
                }

                try {
                    // Update access mode
                    data.isPublic = action === 'public';

                    // Save updated data
                    writeMessageCountData(data);

                    await sock.sendMessage(chatId, { text: `Bot is now in *${action}* mode`, ...channelInfo });
                } catch (error) {
                    console.error('Error updating access mode:', error);
                    await sock.sendMessage(chatId, { text: 'Failed to update bot access mode', ...channelInfo });
                }
                break;
            case userMessage.startsWith('.anticall'):
                if (!message.key.fromMe && !senderIsOwnerOrSudo) {
                    await sock.sendMessage(chatId, { text: 'Only owner/sudo can use anticall.' });
                    break;
                }
                {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    await anticallCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.pmblocker'):
                {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    await pmblockerCommand(sock, chatId, message, args);
                }
                commandExecuted = true;
                break;
            case userMessage === '.owner':
                await ownerCommand(sock, chatId);
                break;
            case userMessage === '.twilio':
                await twilioCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.pair'):
                {
                    const pairArgs = rawText.slice(5).trim();
                    await pairCommand(sock, chatId, message, pairArgs);
                }
                commandExecuted = true;
                break;
            case userMessage === '.tagall':
                await tagAllCommand(sock, chatId, senderId, message);
                break;
            case userMessage === '.tagnotadmin':
                await tagNotAdminCommand(sock, chatId, senderId, message);
                break;
            case userMessage.startsWith('.hidetag'):
                {
                    const messageText = rawText.slice(8).trim();
                    const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                    await hideTagCommand(sock, chatId, senderId, messageText, replyMessage, message);
                }
                break;
            case userMessage.startsWith('.tag'):
                const messageText = rawText.slice(4).trim();  // use rawText here, not userMessage
                const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                await tagCommand(sock, chatId, senderId, messageText, replyMessage, message);
                break;
            case userMessage.startsWith('.antilink'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups.',
                        ...channelInfo
                    });
                    return;
                }
                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: 'Please make the bot an admin first.',
                        ...channelInfo
                    });
                    return;
                }
                await handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                break;
            case userMessage.startsWith('.antitag'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups.',
                        ...channelInfo
                    });
                    return;
                }
                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: 'Please make the bot an admin first.',
                        ...channelInfo
                    });
                    return;
                }
                await handleAntitagCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                break;
            case userMessage === '.meme':
                await memeCommand(sock, chatId, message);
                break;
            case userMessage === '.joke':
                await jokeCommand(sock, chatId, message);
                break;
            case userMessage === '.quote':
                await quoteCommand(sock, chatId, message);
                break;
            case userMessage === '.fact':
                await factCommand(sock, chatId, message, message);
                break;
            case userMessage.startsWith('.weather'):
                const city = userMessage.slice(9).trim();
                if (city) {
                    await weatherCommand(sock, chatId, message, city);
                } else {
                    await sock.sendMessage(chatId, { text: 'Please specify a city, e.g., .weather London', ...channelInfo });
                }
                break;
            case userMessage === '.news':
                await newsCommand(sock, chatId);
                break;
            case userMessage === '.topmembers':
                topMembers(sock, chatId, isGroup);
                break;
            case userMessage.startsWith('.8ball'):
                const question = userMessage.split(' ').slice(1).join(' ');
                await eightBallCommand(sock, chatId, question);
                break;
            case userMessage.startsWith('.lyrics'):
                const songTitle = userMessage.split(' ').slice(1).join(' ');
                await lyricsCommand(sock, chatId, songTitle, message);
                break;
            case userMessage === '.clear':
                if (isGroup) await clearCommand(sock, chatId);
                break;
            case userMessage.startsWith('.promote'):
                const mentionedJidListPromote = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await promoteCommand(sock, chatId, mentionedJidListPromote, message);
                break;
            case userMessage.startsWith('.demote'):
                const mentionedJidListDemote = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await demoteCommand(sock, chatId, mentionedJidListDemote, message);
                break;
            case userMessage === '.ping':
                await pingCommand(sock, chatId, message);
                break;
            case userMessage === '.alive':
                await aliveCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.mention '):
                {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    const isOwner = message.key.fromMe || senderIsSudo;
                    await mentionToggleCommand(sock, chatId, message, args, isOwner);
                }
                break;
            case userMessage === '.setmention':
                {
                    const isOwner = message.key.fromMe || senderIsSudo;
                    await setMentionCommand(sock, chatId, message, isOwner);
                }
                break;
            case userMessage.startsWith('.blur'):
                const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                await blurCommand(sock, chatId, message, quotedMessage);
                break;
            case userMessage.startsWith('.welcome'):
                if (isGroup) {
                    // Check admin status if not already checked
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }

                    if (isSenderAdmin || message.key.fromMe) {
                        await welcomeCommand(sock, chatId, message);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Sorry, only group admins can use this command.', ...channelInfo });
                    }
                } else {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups.', ...channelInfo });
                }
                break;
            case userMessage.startsWith('.goodbye'):
                if (isGroup) {
                    // Check admin status if not already checked
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }

                    if (isSenderAdmin || message.key.fromMe) {
                        await goodbyeCommand(sock, chatId, message);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Sorry, only group admins can use this command.', ...channelInfo });
                    }
                } else {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups.', ...channelInfo });
                }
                break;
            case userMessage.startsWith('.antibadword'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups.', ...channelInfo });
                    return;
                }

                const adminStatus = await isAdmin(sock, chatId, senderId);
                isSenderAdmin = adminStatus.isSenderAdmin;
                isBotAdmin = adminStatus.isBotAdmin;

                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, { text: '*Bot must be admin to use this feature*', ...channelInfo });
                    return;
                }

                await antibadwordCommand(sock, chatId, message, senderId, isSenderAdmin);
                break;
            case userMessage.startsWith('.chatbot'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups.', ...channelInfo });
                    return;
                }

                // Check if sender is admin or bot owner
                const chatbotAdminStatus = await isAdmin(sock, chatId, senderId);
                if (!chatbotAdminStatus.isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, { text: '*Only admins or bot owner can use this command*', ...channelInfo });
                    return;
                }

                const match = userMessage.slice(8).trim();
                await handleChatbotCommand(sock, chatId, message, match);
                break;
            case userMessage.startsWith('.take') || userMessage.startsWith('.steal'):
                {
                    const isSteal = userMessage.startsWith('.steal');
                    const sliceLen = isSteal ? 6 : 5; // '.steal' vs '.take'
                    const takeArgs = rawText.slice(sliceLen).trim().split(' ');
                    await takeCommand(sock, chatId, message, takeArgs);
                }
                break;
            case userMessage === '.groupinfo' || userMessage === '.infogp' || userMessage === '.infogrupo':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups!', ...channelInfo });
                    return;
                }
                await groupInfoCommand(sock, chatId, message);
                break;
            case userMessage === '.resetlink' || userMessage === '.revoke' || userMessage === '.anularlink':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups!', ...channelInfo });
                    return;
                }
                await resetlinkCommand(sock, chatId, senderId);
                break;
            case userMessage === '.staff' || userMessage === '.admins' || userMessage === '.listadmin':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups!', ...channelInfo });
                    return;
                }
                await staffCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.tourl') || userMessage.startsWith('.url'):
                await urlCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.emojimix') || userMessage.startsWith('.emix'):
                await emojimixCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.tg') || userMessage.startsWith('.stickertelegram') || userMessage.startsWith('.tgsticker') || userMessage.startsWith('.telesticker'):
                await stickerTelegramCommand(sock, chatId, message);
                break;

            case userMessage === '.vv':
                await viewOnceCommand(sock, chatId, message);
                break;
            case userMessage === '.clearsession' || userMessage === '.clearsesi':
                await clearSessionCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.autostatus'):
                const autoStatusArgs = userMessage.split(' ').slice(1);
                await autoStatusCommand(sock, chatId, message, autoStatusArgs);
                break;
            case userMessage.startsWith('.antidelete'):
                const antideleteMatch = userMessage.slice(11).trim();
                await handleAntideleteCommand(sock, chatId, message, antideleteMatch);
                break;
            case userMessage === '.cleartmp':
                await clearTmpCommand(sock, chatId, message);
                break;
            case userMessage === '.setpp':
                await setProfilePicture(sock, chatId, message);
                break;
            case userMessage.startsWith('.setgdesc'):
                {
                    const text = rawText.slice(9).trim();
                    await setGroupDescription(sock, chatId, senderId, text, message);
                }
                break;
            case userMessage.startsWith('.setgname'):
                {
                    const text = rawText.slice(9).trim();
                    await setGroupName(sock, chatId, senderId, text, message);
                }
                break;
            case userMessage.startsWith('.setgpp'):
                await setGroupPhoto(sock, chatId, senderId, message);
                break;
            case userMessage.startsWith('.instagram') || userMessage.startsWith('.insta') || (userMessage === '.ig' || userMessage.startsWith('.ig ')):
                await instagramCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.igsc'):
                await igsCommand(sock, chatId, message, true);
                break;
            case userMessage.startsWith('.igs'):
                await igsCommand(sock, chatId, message, false);
                break;
            case userMessage.startsWith('.fb') || userMessage.startsWith('.facebook'):
                await facebookCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.music'):
                await ytmp3Command(sock, chatId, message);
                break;
            case userMessage.startsWith('.spotify'):
                await spotifyCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.ytmp3') || userMessage.startsWith('.mp3'):
                await ytmp3Command(sock, chatId, message);
                break;
            case userMessage.startsWith('.video') || userMessage.startsWith('.ytmp4'):
                await videoCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.tomp3') || userMessage.startsWith('.mp4tomp3') || userMessage.startsWith('.vtomp3'):
                await toMp3Command(sock, chatId, message);
                break;
            case userMessage.startsWith('.tiktok') || userMessage.startsWith('.tt'):
                await tiktokCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.translate') || userMessage.startsWith('.trt'):
                const commandLength = userMessage.startsWith('.translate') ? 10 : 4;
                await handleTranslateCommand(sock, chatId, message, userMessage.slice(commandLength));
                return;
            case userMessage.startsWith('.ss') || userMessage.startsWith('.ssweb') || userMessage.startsWith('.screenshot'):
                const ssCommandLength = userMessage.startsWith('.screenshot') ? 11 : (userMessage.startsWith('.ssweb') ? 6 : 3);
                await handleSsCommand(sock, chatId, message, userMessage.slice(ssCommandLength).trim());
                break;
            case userMessage.startsWith('.areact') || userMessage.startsWith('.autoreact') || userMessage.startsWith('.autoreaction'):
                await handleAreactCommand(sock, chatId, message, isOwnerOrSudoCheck);
                break;
            case userMessage.startsWith('.sudo'):
                await sudoCommand(sock, chatId, message);
                break;
            case userMessage === '.jid': await groupJidCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.autotyping'):
                await autotypingCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.autoread'):
                await autoreadCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.simpcard'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['simpcard', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.tonikawa'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['tonikawa', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.animu'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = parts.slice(1);
                    await animeCommand(sock, chatId, message, args);
                }
                break;
            case userMessage === '.crop':
                await stickercropCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.update'):
                {
                    const parts = rawText.trim().split(/\s+/);
                    const zipArg = parts[1] && parts[1].startsWith('http') ? parts[1] : '';
                    await updateCommand(sock, chatId, message, zipArg);
                }
                commandExecuted = true;
                break;
            case userMessage.startsWith('.removebg') || userMessage.startsWith('.rmbg') || userMessage.startsWith('.nobg'):
                await removebgCommand.exec(sock, message, userMessage.split(' ').slice(1));
                break;
            case userMessage.startsWith('.remini') || userMessage.startsWith('.enhance') || userMessage.startsWith('.upscale'):
                await reminiCommand(sock, chatId, message, userMessage.split(' ').slice(1));
                break;
            case userMessage.startsWith('.schedule'):
                if (isGroup) {
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }

                    if (!isSenderAdmin && !senderIsOwnerOrSudo && !message.key.fromMe) {
                        await sock.sendMessage(chatId, { text: '❌ Hanya admin group atau owner/sudo boleh guna .schedule' });
                        break;
                    }
                } else if (!message.key.fromMe && !senderIsOwnerOrSudo) {
                    await sock.sendMessage(chatId, { text: '❌ Hanya owner/sudo boleh guna .schedule di private chat' });
                    break;
                }

                await scheduleCommand(sock, chatId, message, rawText, senderId);
                commandExecuted = true;
                break;
            default: {
                // Check custom commands first
                let customHandled = false;
                try {
                    const customCmds = JSON.parse(fs.readFileSync('./data/customCommands.json', 'utf8'));
                    const lowerMsg = userMessage.toLowerCase();
                    const matched = customCmds.find(c => {
                        const t = (c.trigger || '').toLowerCase();
                        return lowerMsg === t || lowerMsg.startsWith(t + ' ');
                    });
                    if (matched) {
                        const caption = (matched.response || '').replace(/\\n/g, '\n');
                        const customButtons = normalizeCustomCommandButtons(matched.buttons);
                        const sendMedia = async () => {
                            if (matched.mediaUrl && matched.mediaType) {
                                const mt = matched.mediaType;
                                if (mt === 'url') {
                                    const txt = caption ? `${caption}\n${matched.mediaUrl}` : matched.mediaUrl;
                                    if (customButtons.nativeButtons) {
                                        await sendInteractiveButtons(sock, chatId, {
                                            text: txt,
                                            nativeButtons: customButtons.nativeButtons
                                        });
                                    } else {
                                        await sock.sendMessage(chatId, { text: txt });
                                    }
                                } else {
                                    const isLocal = matched.mediaUrl.startsWith('/uploads/');
                                    const mediaSrc = isLocal
                                        ? fs.readFileSync(path.join(__dirname, 'public', matched.mediaUrl))
                                        : { url: matched.mediaUrl };
                                    const displayName = matched.fileName || (isLocal ? path.basename(matched.mediaUrl) : 'file');
                                    const hasButtons = Boolean(customButtons.nativeButtons);
                                    const payload = hasButtons ? {} : { caption };

                                    // Send interactive buttons first so they are not visually buried by media on some clients.
                                    if (hasButtons) {
                                        await sendInteractiveButtons(sock, chatId, {
                                            text: caption || 'Choose an option:',
                                            nativeButtons: customButtons.nativeButtons
                                        });
                                    }

                                    if (mt === 'image') {
                                        await sock.sendMessage(chatId, { image: mediaSrc, ...payload });
                                    } else if (mt === 'video') {
                                        await sock.sendMessage(chatId, { video: mediaSrc, ...payload });
                                    } else if (mt === 'audio') {
                                        await sock.sendMessage(chatId, { audio: mediaSrc, mimetype: 'audio/mpeg', ptt: false, ...payload });
                                    } else if (mt === 'document') {
                                        await sock.sendMessage(chatId, { document: mediaSrc, fileName: displayName, mimetype: 'application/octet-stream', ...payload });
                                    }
                                }
                            } else if (caption) {
                                if (customButtons.nativeButtons) {
                                    await sendInteractiveButtons(sock, chatId, {
                                        text: caption,
                                        nativeButtons: customButtons.nativeButtons
                                    });
                                } else {
                                    await sock.sendMessage(chatId, { text: caption });
                                }
                            }
                        };
                        try {
                            await sendMedia();
                        } catch (sendErr) {
                            console.error('❌ Custom command send error:', sendErr.message);
                        }
                        customHandled = true;
                        commandExecuted = true;
                    }
                } catch (err) {
                    if (err.code !== 'ENOENT') console.error('❌ Custom command load error:', err.message);
                }

                if (!customHandled) {
                    if (isGroup) {
                        // Handle non-command group messages
                        if (userMessage) {
                            await handleChatbotResponse(sock, chatId, message, userMessage, senderId);
                        }
                        await handleTagDetection(sock, chatId, message, senderId);
                        await handleMentionDetection(sock, chatId, message);
                    }
                    commandExecuted = false;
                }
                break;
            }
        }

        // If a command was executed, show typing status after command execution
        if (commandExecuted !== false) {
            // Command was executed, now show typing status after command execution
            await showTypingAfterCommand(sock, chatId);
        }

        // Function to handle .groupjid command
        async function groupJidCommand(sock, chatId, message) {
            const groupJid = message.key.remoteJid;

            if (!groupJid.endsWith('@g.us')) {
                return await sock.sendMessage(chatId, {
                    text: "❌ This command can only be used in a group."
                });
            }

            await sock.sendMessage(chatId, {
                text: `✅ Group JID: ${groupJid}`
            });
        }

        if (userMessage.startsWith('.')) {
            // After command is processed successfully
            await addCommandReaction(sock, message);
        }
    } catch (error) {
        console.error('❌ Error in message handler:', error.message);
        // Only try to send error message if we have a valid chatId
        if (chatId) {
            await sock.sendMessage(chatId, {
                text: '❌ Failed to process command!',
                ...channelInfo
            });
        }
    }
}

async function handleGroupParticipantUpdate(sock, update) {
    try {
        const { id, participants, action, author } = update;

        // Check if it's a group
        if (!id.endsWith('@g.us')) return;

        // Respect bot mode: only announce promote/demote in public mode
        let isPublic = true;
        const modeData = readMessageCountData();
        if (typeof modeData.isPublic === 'boolean') isPublic = modeData.isPublic;

        // Handle promotion events
        if (action === 'promote') {
            if (!isPublic) return;
            await handlePromotionEvent(sock, id, participants, author);
            return;
        }

        // Handle demotion events
        if (action === 'demote') {
            if (!isPublic) return;
            await handleDemotionEvent(sock, id, participants, author);
            return;
        }

        // Handle join events
        if (action === 'add') {
            await handleJoinEvent(sock, id, participants);
        }

        // Handle leave events
        if (action === 'remove') {
            await handleLeaveEvent(sock, id, participants);
        }
    } catch (error) {
        console.error('Error in handleGroupParticipantUpdate:', error);
    }
}

// Instead, export the handlers along with handleMessages
module.exports = {
    handleMessages,
    handleGroupParticipantUpdate,
    handleStatus: async (sock, status) => {
        await handleStatusUpdate(sock, status);
    }
};